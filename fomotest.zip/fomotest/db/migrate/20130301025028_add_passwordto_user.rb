class AddPasswordtoUser < ActiveRecord::Migration
  def up
  end

  def down
  end
end
