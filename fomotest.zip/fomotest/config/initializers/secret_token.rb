# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Fomotest::Application.config.secret_token = 'b63938a055feb6933496690b34ec34c3890464d43ff489e8fd3fca17451aa46da0a7e3a7b61eedf6893d6328824381b9286297d9424506ee8ca9aa3f30e98fbe'
