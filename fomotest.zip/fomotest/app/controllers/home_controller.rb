class HomeController < ApplicationController 

	def index
	end

	def about
	end
	
	def faq
	end

end
